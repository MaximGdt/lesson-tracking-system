<?php

return [
    'failed' => 'Неправильний email або пароль.',
    'password' => 'Невірний пароль.',
    'throttle' => 'Забагато спроб входу. Будь ласка, спробуйте через :seconds секунд.',
    'login' => 'Вхід',
    'logout' => 'Вийти',
    'register' => 'Реєстрація',
    'remember_me' => 'Запам\'ятати мене',
    'forgot_password' => 'Забули пароль?',
    'reset_password' => 'Скинути пароль',
];