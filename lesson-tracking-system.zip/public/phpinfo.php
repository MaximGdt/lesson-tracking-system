<?php

use PHPUnit\TextUI\Configuration\Php;

 phpinfo();