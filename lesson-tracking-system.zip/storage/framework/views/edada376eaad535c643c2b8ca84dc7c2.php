<div class="dropdown">
    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="bi bi-globe"></i> <?php echo e(strtoupper(app()->getLocale())); ?>

    </button>
    <ul class="dropdown-menu dropdown-menu-end">
        <li>
            <a class="dropdown-item <?php echo e(app()->getLocale() == 'uk' ? 'active' : ''); ?>" 
               href="<?php echo e(route('locale.set', 'uk')); ?>">
                🇺🇦 Українська
            </a>
        </li>
        <li>
            <a class="dropdown-item <?php echo e(app()->getLocale() == 'en' ? 'active' : ''); ?>" 
               href="<?php echo e(route('locale.set', 'en')); ?>">
                🇬🇧 English
            </a>
        </li>
    </ul>
</div>
<?php /**PATH C:\Apache24\htdocs\lesson-tracking-system\resources\views/components/language-switcher.blade.php ENDPATH**/ ?>