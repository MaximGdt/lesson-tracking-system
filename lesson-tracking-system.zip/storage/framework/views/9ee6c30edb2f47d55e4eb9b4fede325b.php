

<?php $__env->startSection('title', 'Просмотр расписания'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Детали занятия</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <a href="<?php echo e(route('admin.schedules.edit', $schedule)); ?>" class="btn btn-primary">
                <i class="bi bi-pencil"></i> Редактировать
            </a>
        </div>
        <a href="<?php echo e(route('admin.schedules.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Назад
        </a>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <!-- Schedule Info -->
        <div class="card mb-3">
            <div class="card-header">
                <h5 class="mb-0">Информация о занятии</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <dl>
                            <dt>Дата и время:</dt>
                            <dd>
                                <?php echo e($schedule->date->format('d.m.Y')); ?> 
                                (<?php echo e($schedule->date->translatedFormat('l')); ?>)<br>
                                <?php echo e($schedule->time_range); ?>

                            </dd>
                            
                            <dt>Группа:</dt>
                            <dd>
                                <strong><?php echo e($schedule->group->code); ?></strong><br>
                                <?php echo e($schedule->group->name); ?>

                            </dd>
                            
                            <dt>Преподаватель:</dt>
                            <dd>
                                <?php echo e($schedule->teacher->full_name); ?><br>
                                <small class="text-muted"><?php echo e($schedule->teacher->email); ?></small>
                            </dd>
                        </dl>
                    </div>
                    <div class="col-md-6">
                        <dl>
                            <dt>Предмет:</dt>
                            <dd><?php echo e($schedule->subject); ?></dd>
                            
                            <dt>Тип занятия:</dt>
                            <dd><span class="badge bg-info"><?php echo e($schedule->type_display); ?></span></dd>
                            
                            <dt>Аудитория:</dt>
                            <dd><?php echo e($schedule->room ?? '-'); ?></dd>
                            
                            <dt>Статус:</dt>
                            <dd>
                                <?php if($schedule->is_cancelled): ?>
                                    <span class="badge bg-secondary">Отменено</span>
                                    <br><small><?php echo e($schedule->cancellation_reason); ?></small>
                                <?php elseif($schedule->lesson && $schedule->lesson->is_conducted): ?>
                                    <span class="badge bg-success">Проведено</span>
                                <?php elseif($schedule->isPast()): ?>
                                    <span class="badge bg-warning">Не отмечено</span>
                                <?php else: ?>
                                    <span class="badge bg-light text-dark">Запланировано</span>
                                <?php endif; ?>
                            </dd>
                        </dl>
                    </div>
                </div>
                
                <?php if($schedule->notes): ?>
                    <hr>
                    <p class="mb-0"><strong>Примечания к расписанию:</strong><br>
                    <?php echo e($schedule->notes); ?></p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Lesson Details -->
        <?php if($schedule->lesson): ?>
            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0">Детали проведения</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <dl>
                                <dt>Статус проведения:</dt>
                                <dd>
                                    <?php if($schedule->lesson->is_conducted): ?>
                                        <span class="badge bg-success">Проведено</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Не проведено</span>
                                    <?php endif; ?>
                                </dd>
                                
                                <dt>Отмечено:</dt>
                                <dd>
                                    <?php if($schedule->lesson->marked_at): ?>
                                        <?php echo e($schedule->lesson->marked_at->format('d.m.Y H:i')); ?><br>
                                        <small class="text-muted"><?php echo e($schedule->lesson->markedBy->full_name); ?></small>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </dd>
                            </dl>
                        </div>
                        <div class="col-md-6">
                            <dl>
                                <dt>Присутствовало студентов:</dt>
                                <dd>
                                    <?php if($schedule->lesson->students_present !== null): ?>
                                        <?php echo e($schedule->lesson->students_present); ?> из <?php echo e($schedule->group->students->count()); ?>

                                        <?php if($schedule->lesson->attendance_percentage): ?>
                                            <span class="badge bg-info"><?php echo e($schedule->lesson->attendance_percentage); ?>%</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </dd>
                            </dl>
                        </div>
                    </div>
                    
                    <?php if($schedule->lesson->notes): ?>
                        <hr>
                        <p class="mb-0"><strong>Примечания к занятию:</strong><br>
                        <?php echo e($schedule->lesson->notes); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Actions -->
        <div class="card">
            <div class="card-body">
                <div class="d-flex gap-2">
                    <?php if(!$schedule->is_cancelled && (!$schedule->lesson || !$schedule->lesson->is_conducted)): ?>
                        <button type="button" 
                                class="btn btn-warning" 
                                data-bs-toggle="modal" 
                                data-bs-target="#cancelModal">
                            <i class="bi bi-x-circle"></i> Отменить занятие
                        </button>
                        
                        <form method="POST" 
                              action="<?php echo e(route('admin.schedules.destroy', $schedule)); ?>" 
                              onsubmit="return confirm('Удалить занятие из расписания?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">
                                <i class="bi bi-trash"></i> Удалить
                            </button>
                        </form>
                    <?php endif; ?>
                    
                    <a href="<?php echo e(route('admin.schedules.edit', $schedule)); ?>" class="btn btn-primary">
                        <i class="bi bi-pencil"></i> Редактировать
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Apache24\htdocs\lesson-tracking-system\resources\views/admin/schedules/show.blade.php ENDPATH**/ ?>