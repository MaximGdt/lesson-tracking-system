

<?php $__env->startSection('title', 'Мое расписание'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Мое расписание</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <a href="<?php echo e(route('teacher.schedule.calendar')); ?>" class="btn btn-outline-primary">
                <i class="bi bi-calendar3"></i> Календарь
            </a>
        </div>
        <button type="button" class="btn btn-secondary" onclick="window.print()">
            <i class="bi bi-printer"></i> Печать
        </button>
    </div>
</div>

<!-- Date Navigation -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('teacher.schedule')); ?>" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label">С даты</label>
                <input type="date" name="start_date" class="form-control" 
                       value="<?php echo e($startDate->format('Y-m-d')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">По дату</label>
                <input type="date" name="end_date" class="form-control" 
                       value="<?php echo e($endDate->format('Y-m-d')); ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-search"></i> Показать
                </button>
                <a href="<?php echo e(route('teacher.schedule')); ?>" class="btn btn-secondary">
                    Текущая неделя
                </a>
            </div>
            <div class="col-md-2 text-end">
                <div class="btn-group">
                    <a href="<?php echo e(route('teacher.schedule', ['start_date' => $startDate->copy()->subWeek()->format('Y-m-d'), 'end_date' => $endDate->copy()->subWeek()->format('Y-m-d')])); ?>" 
                       class="btn btn-outline-primary">
                        <i class="bi bi-chevron-left"></i>
                    </a>
                    <a href="<?php echo e(route('teacher.schedule', ['start_date' => $startDate->copy()->addWeek()->format('Y-m-d'), 'end_date' => $endDate->copy()->addWeek()->format('Y-m-d')])); ?>" 
                       class="btn btn-outline-primary">
                        <i class="bi bi-chevron-right"></i>
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Schedule Display -->
<?php if($schedules->isEmpty()): ?>
    <div class="alert alert-info text-center">
        <i class="bi bi-calendar-x"></i> На выбранный период занятий нет
    </div>
<?php else: ?>
    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $daySchedules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <div class="card-header <?php echo e(Carbon\Carbon::parse($date)->isToday() ? 'bg-primary text-white' : ''); ?>">
                <h5 class="mb-0">
                    <?php echo e(Carbon\Carbon::parse($date)->translatedFormat('l, d F Y')); ?>

                    <?php if(Carbon\Carbon::parse($date)->isToday()): ?>
                        <span class="badge bg-white text-primary ms-2">Сегодня</span>
                    <?php endif; ?>
                </h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th width="15%">Время</th>
                                <th width="15%">Группа</th>
                                <th width="30%">Предмет</th>
                                <th width="10%">Тип</th>
                                <th width="10%">Аудитория</th>
                                <th width="15%">Статус</th>
                                <th width="5%"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $daySchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="<?php echo e($schedule->is_cancelled ? 'table-secondary' : ''); ?>">
                                    <td>
                                        <strong><?php echo e($schedule->start_time->format('H:i')); ?></strong> - 
                                        <?php echo e($schedule->end_time->format('H:i')); ?>

                                    </td>
                                    <td>
                                        <strong><?php echo e($schedule->group->code); ?></strong><br>
                                        <small class="text-muted"><?php echo e($schedule->group->name); ?></small>
                                    </td>
                                    <td><?php echo e($schedule->subject); ?></td>
                                    <td>
                                        <span class="badge bg-info"><?php echo e($schedule->type_display); ?></span>
                                    </td>
                                    <td><?php echo e($schedule->room ?? '-'); ?></td>
                                    <td>
                                        <?php if($schedule->is_cancelled): ?>
                                            <span class="badge bg-secondary">Отменено</span>
                                        <?php elseif($schedule->lesson && $schedule->lesson->is_conducted): ?>
                                            <span class="badge bg-success">
                                                <i class="bi bi-check-circle"></i> Проведено
                                            </span>
                                        <?php elseif($schedule->isPast()): ?>
                                            <span class="badge bg-warning">Не отмечено</span>
                                        <?php else: ?>
                                            <span class="badge bg-light text-dark">Запланировано</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('teacher.lessons.show', $schedule)); ?>" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<!-- Summary -->
<div class="row mt-4">
    <div class="col-md-4">
        <div class="card text-center">
            <div class="card-body">
                <h3 class="text-primary"><?php echo e($schedules->flatten()->count()); ?></h3>
                <p class="mb-0">Всего занятий</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-center">
            <div class="card-body">
                <h3 class="text-success">
                    <?php echo e($schedules->flatten()->filter(function($s) { 
                        return $s->lesson && $s->lesson->is_conducted; 
                    })->count()); ?>

                </h3>
                <p class="mb-0">Проведено</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-center">
            <div class="card-body">
                <h3 class="text-info"><?php echo e($groups->count()); ?></h3>
                <p class="mb-0">Групп</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Apache24\htdocs\lesson-tracking-system\resources\views/teacher/schedule.blade.php ENDPATH**/ ?>