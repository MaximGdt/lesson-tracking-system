

<?php $__env->startSection('title', 'Управление пользователями'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Пользователи</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Добавить пользователя
        </a>
    </div>
</div>

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.users.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Поиск</label>
                <input type="text" name="search" class="form-control" placeholder="Имя, фамилия, email" 
                       value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Роль</label>
                <select name="role" class="form-select">
                    <option value="">Все роли</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->name); ?>" <?php echo e(request('role') == $role->name ? 'selected' : ''); ?>>
                            <?php echo e($role->display_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Статус</label>
                <select name="status" class="form-select">
                    <option value="">Все</option>
                    <option value="1" <?php echo e(request('status') == '1' ? 'selected' : ''); ?>>Активные</option>
                    <option value="0" <?php echo e(request('status') == '0' ? 'selected' : ''); ?>>Неактивные</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary me-2">
                    <i class="bi bi-search"></i> Поиск
                </button>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary">
                    <i class="bi bi-x"></i> Сброс
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Users Table -->
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ФИО</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Роли</th>
                    <th>Статус</th>
                    <th>Последний вход</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->full_name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->phone ?? '-'); ?></td>
                        <td>
                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-primary badge-role"><?php echo e($role->display_name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php if($user->is_active): ?>
                                <span class="badge bg-success">Активен</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Неактивен</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($user->last_login_at): ?>
                                <small><?php echo e($user->last_login_at->format('d.m.Y H:i')); ?></small>
                            <?php else: ?>
                                <small class="text-muted">-</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.users.show', $user)); ?>" 
                                   class="btn btn-sm btn-info btn-action" 
                                   title="Просмотр">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.users.edit', $user)); ?>" 
                                   class="btn btn-sm btn-primary btn-action" 
                                   title="Редактировать">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                
                                <?php if($user->id !== auth()->id()): ?>
                                    <form method="POST" 
                                          action="<?php echo e(route('admin.users.toggle-status', $user)); ?>" 
                                          class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" 
                                                class="btn btn-sm btn-warning btn-action" 
                                                title="<?php echo e($user->is_active ? 'Деактивировать' : 'Активировать'); ?>">
                                            <i class="bi bi-<?php echo e($user->is_active ? 'lock' : 'unlock'); ?>"></i>
                                        </button>
                                    </form>
                                    
                                    <form method="POST" 
                                          action="<?php echo e(route('admin.users.destroy', $user)); ?>" 
                                          class="d-inline"
                                          onsubmit="return confirm('Вы уверены, что хотите удалить этого пользователя?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" 
                                                class="btn btn-sm btn-danger btn-action" 
                                                title="Удалить">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-muted">
                            Пользователи не найдены
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Pagination -->
<div class="mt-3">
    <?php echo e($users->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Apache24\htdocs\lesson-tracking-system\resources\views/admin/users/index.blade.php ENDPATH**/ ?>