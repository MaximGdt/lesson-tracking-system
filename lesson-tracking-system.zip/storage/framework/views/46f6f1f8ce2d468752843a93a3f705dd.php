

<?php $__env->startSection('title', 'Управление группами'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Группы</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.groups.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Добавить группу
        </a>
    </div>
</div>

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.groups.index')); ?>" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Поиск</label>
                <input type="text" name="search" class="form-control" 
                       placeholder="Название или код группы" 
                       value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Курс</label>
                <select name="course" class="form-select">
                    <option value="">Все курсы</option>
                    <?php for($i = 1; $i <= 6; $i++): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e(request('course') == $i ? 'selected' : ''); ?>>
                            <?php echo e($i); ?> курс
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Статус</label>
                <select name="status" class="form-select">
                    <option value="">Все</option>
                    <option value="1" <?php echo e(request('status') == '1' ? 'selected' : ''); ?>>Активные</option>
                    <option value="0" <?php echo e(request('status') == '0' ? 'selected' : ''); ?>>Неактивные</option>
                </select>
            </div>
            <div class="col-md-4 d-flex align-items-end">
                <button type="submit" class="btn btn-primary me-2">
                    <i class="bi bi-search"></i> Поиск
                </button>
                <a href="<?php echo e(route('admin.groups.index')); ?>" class="btn btn-secondary">
                    <i class="bi bi-x"></i> Сброс
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Groups Table -->
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Код</th>
                    <th>Название</th>
                    <th>Курс</th>
                    <th>Специальность</th>
                    <th>Студентов</th>
                    <th>Преподавателей</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong><?php echo e($group->code); ?></strong></td>
                        <td><?php echo e($group->name); ?></td>
                        <td><?php echo e($group->course); ?></td>
                        <td><?php echo e($group->speciality ?? '-'); ?></td>
                        <td>
                            <span class="badge bg-info"><?php echo e($group->students_count); ?></span>
                        </td>
                        <td>
                            <span class="badge bg-primary"><?php echo e($group->teachers_count); ?></span>
                        </td>
                        <td>
                            <?php if($group->is_active): ?>
                                <span class="badge bg-success">Активна</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Неактивна</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.groups.show', $group)); ?>" 
                                   class="btn btn-sm btn-info btn-action" 
                                   title="Просмотр">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.groups.edit', $group)); ?>" 
                                   class="btn btn-sm btn-primary btn-action" 
                                   title="Редактировать">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form method="POST" 
                                      action="<?php echo e(route('admin.groups.sync-students', $group)); ?>" 
                                      class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" 
                                            class="btn btn-sm btn-success btn-action" 
                                            title="Синхронизировать студентов">
                                        <i class="bi bi-arrow-repeat"></i>
                                    </button>
                                </form>
                                <form method="POST" 
                                      action="<?php echo e(route('admin.groups.destroy', $group)); ?>" 
                                      class="d-inline"
                                      onsubmit="return confirm('Вы уверены? Все связанные данные будут удалены!');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="btn btn-sm btn-danger btn-action" 
                                            title="Удалить">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-muted">
                            Группы не найдены
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Pagination -->
<div class="mt-3">
    <?php echo e($groups->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Apache24\htdocs\lesson-tracking-system\resources\views/admin/groups/index.blade.php ENDPATH**/ ?>