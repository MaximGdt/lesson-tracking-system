<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Система учета занятий'); ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #34495e;
            --success-color: #27ae60;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --info-color: #3498db;
        }

        body {
            background-color: #f8f9fa;
        }

        .navbar {
            background-color: var(--primary-color) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,.1);
        }

        .sidebar {
            background-color: var(--secondary-color);
            min-height: calc(100vh - 56px);
            padding: 20px 0;
        }

        .sidebar .nav-link {
            color: #ecf0f1;
            padding: 10px 20px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover {
            background-color: rgba(255,255,255,0.1);
            padding-left: 25px;
        }

        .sidebar .nav-link.active {
            background-color: var(--primary-color);
            border-left: 4px solid var(--success-color);
        }

        .content-wrapper {
            padding: 20px;
        }

        .card {
            border: none;
            box-shadow: 0 0 10px rgba(0,0,0,.1);
            transition: transform 0.2s;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,.15);
        }

        .stat-card {
            border-left: 4px solid;
        }

        .stat-card.primary { border-left-color: var(--info-color); }
        .stat-card.success { border-left-color: var(--success-color); }
        .stat-card.warning { border-left-color: var(--warning-color); }
        .stat-card.danger { border-left-color: var(--danger-color); }

        .badge-role {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }

        .table-hover tbody tr:hover {
            background-color: rgba(0,0,0,.02);
        }

        .btn-action {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }

        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
   <!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(route('login')); ?>">
            <i class="bi bi-calendar-check"></i> <?php echo e(__('app.app_name')); ?>

        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <?php if(auth()->guard()->check()): ?>
                    <!-- Language Switcher -->
                    <li class="nav-item me-2">
                        <?php echo $__env->make('components.language-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </li>
                    
                    <!-- User Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <?php if(auth()->user()->avatar): ?>
                                <img src="<?php echo e(Storage::url(auth()->user()->avatar)); ?>" 
                                     alt="Avatar" 
                                     class="rounded-circle me-1" 
                                     width="24" height="24">
                            <?php else: ?>
                                <i class="bi bi-person-circle"></i>
                            <?php endif; ?>
                            <?php echo e(auth()->user()->short_name); ?>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">
                                <i class="bi bi-person"></i> <?php echo e(__('app.profile')); ?>

                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">
                                        <i class="bi bi-box-arrow-right"></i> <?php echo e(__('auth.logout')); ?>

                                    </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                <?php else: ?>
                    <!-- Language Switcher for guests -->
                    <li class="nav-item">
                        <?php echo $__env->make('components.language-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

    <div class="container-fluid">
        <div class="row">
            <?php if(auth()->guard()->check()): ?>
                <!-- Sidebar -->
                <nav class="col-md-3 col-lg-2 d-md-block sidebar">
                    <div class="position-sticky">
                        <?php if(auth()->user()->isAdmin()): ?>
                            <h6 class="text-white px-3 mb-3">Администрирование</h6>
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>" 
                                       href="<?php echo e(route('admin.dashboard')); ?>">
                                        <i class="bi bi-speedometer2"></i> Панель управления
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>" 
                                       href="<?php echo e(route('admin.users.index')); ?>">
                                        <i class="bi bi-people"></i> Пользователи
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->routeIs('admin.groups.*') ? 'active' : ''); ?>" 
                                       href="<?php echo e(route('admin.groups.index')); ?>">
                                        <i class="bi bi-collection"></i> Группы
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->routeIs('admin.schedules.*') ? 'active' : ''); ?>" 
                                       href="<?php echo e(route('admin.schedules.index')); ?>">
                                        <i class="bi bi-calendar3"></i> Расписание
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->routeIs('admin.reports.*') ? 'active' : ''); ?>" 
                                       href="<?php echo e(route('admin.reports.index')); ?>">
                                        <i class="bi bi-file-earmark-bar-graph"></i> Отчеты
                                    </a>
                                </li>
                            </ul>
                        <?php endif; ?>

                        <?php if(auth()->user()->isTeacher()): ?>
                            <h6 class="text-white px-3 mb-3">Преподаватель</h6>
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->routeIs('teacher.dashboard') ? 'active' : ''); ?>" 
                                       href="<?php echo e(route('teacher.dashboard')); ?>">
                                        <i class="bi bi-house"></i> Главная
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->routeIs('teacher.lessons.*') ? 'active' : ''); ?>" 
                                       href="<?php echo e(route('teacher.lessons.index')); ?>">
                                        <i class="bi bi-journal-check"></i> Мои занятия
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->routeIs('teacher.schedule') ? 'active' : ''); ?>" 
                                       href="<?php echo e(route('teacher.schedule')); ?>">
                                        <i class="bi bi-calendar-week"></i> Расписание
                                    </a>
                                </li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </nav>

                <!-- Main content -->
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 content-wrapper">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="bi bi-check-circle"></i> <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-circle"></i> <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            <?php else: ?>
                <!-- Full width content for guests -->
                <main class="col-12">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Alpine.js -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <!-- Custom JS -->
    <script>
        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.classList.remove('show');
                    setTimeout(() => alert.remove(), 150);
                }, 5000);
            });
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Apache24\htdocs\lesson-tracking-system\resources\views/layouts/app.blade.php ENDPATH**/ ?>