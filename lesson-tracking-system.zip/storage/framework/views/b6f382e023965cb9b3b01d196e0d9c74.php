

<?php $__env->startSection('title', 'Просмотр пользователя'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($user->full_name); ?></h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-primary">
                <i class="bi bi-pencil"></i> Редактировать
            </a>
            <?php if($user->id !== auth()->id()): ?>
                <form method="POST" action="<?php echo e(route('admin.users.toggle-status', $user)); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-<?php echo e($user->is_active ? 'warning' : 'success'); ?>">
                        <i class="bi bi-<?php echo e($user->is_active ? 'lock' : 'unlock'); ?>"></i> 
                        <?php echo e($user->is_active ? 'Деактивировать' : 'Активировать'); ?>

                    </button>
                </form>
            <?php endif; ?>
        </div>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Назад
        </a>
    </div>
</div>

<div class="row">
    <div class="col-lg-4 mb-4">
        <!-- User Info -->
        <div class="card mb-3">
            <div class="card-header">
                <h5 class="mb-0">Личная информация</h5>
            </div>
            <div class="card-body">
                <?php if($user->avatar): ?>
                    <div class="text-center mb-3">
                        <img src="<?php echo e(Storage::url($user->avatar)); ?>" 
                             alt="Avatar" 
                             class="rounded-circle" 
                             style="width: 100px; height: 100px; object-fit: cover;">
                    </div>
                <?php endif; ?>
                
                <dl class="mb-0">
                    <dt>ФИО:</dt>
                    <dd><?php echo e($user->full_name); ?></dd>
                    
                    <dt>Email:</dt>
                    <dd>
                        <?php echo e($user->email); ?>

                        <?php if($user->email_verified_at): ?>
                            <i class="bi bi-check-circle text-success" title="Подтвержден"></i>
                        <?php else: ?>
                            <i class="bi bi-x-circle text-danger" title="Не подтвержден"></i>
                        <?php endif; ?>
                    </dd>
                    
                    <dt>Телефон:</dt>
                    <dd><?php echo e($user->phone ?? '-'); ?></dd>
                    
                    <dt>Язык интерфейса:</dt>
                    <dd><?php echo e($user->locale == 'uk' ? 'Українська' : 'English'); ?></dd>
                    
                    <dt>Статус:</dt>
                    <dd>
                        <?php if($user->is_active): ?>
                            <span class="badge bg-success">Активен</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Неактивен</span>
                        <?php endif; ?>
                    </dd>
                </dl>
            </div>
        </div>
        
        <!-- Roles -->
        <div class="card mb-3">
            <div class="card-header">
                <h5 class="mb-0">Роли</h5>
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-2">
                        <span class="badge bg-primary"><?php echo e($role->display_name); ?></span>
                        <?php if($role->description): ?>
                            <br><small class="text-muted"><?php echo e($role->description); ?></small>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        <!-- Activity -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Активность</h5>
            </div>
            <div class="card-body">
                <dl class="mb-0">
                    <dt>Зарегистрирован:</dt>
                    <dd><?php echo e($user->created_at->format('d.m.Y H:i')); ?></dd>
                    
                    <dt>Последний вход:</dt>
                    <dd>
                        <?php if($user->last_login_at): ?>
                            <?php echo e($user->last_login_at->format('d.m.Y H:i')); ?>

                            <br>
                            <small class="text-muted"><?php echo e($user->last_login_at->diffForHumans()); ?></small>
                        <?php else: ?>
                            <span class="text-muted">Не входил</span>
                        <?php endif; ?>
                    </dd>
                    
                    <dt>Последнее обновление:</dt>
                    <dd><?php echo e($user->updated_at->format('d.m.Y H:i')); ?></dd>
                </dl>
            </div>
        </div>
    </div>
    
    <div class="col-lg-8">
        <?php if($user->isTeacher()): ?>
            <!-- Teacher Stats -->
            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0">Статистика преподавателя</h5>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-3">
                            <h3 class="text-primary"><?php echo e($user->groups->count()); ?></h3>
                            <p class="text-muted">Групп</p>
                        </div>
                        <div class="col-md-3">
                            <h3 class="text-info">
                                <?php echo e($user->schedules()->where('date', '>=', today())->count()); ?>

                            </h3>
                            <p class="text-muted">Запланировано</p>
                        </div>
                        <div class="col-md-3">
                            <h3 class="text-success">
                                <?php echo e($user->schedules()
                                    ->whereMonth('date', now()->month)
                                    ->whereHas('lesson', function($q) {
                                        $q->where('is_conducted', true);
                                    })->count()); ?>

                            </h3>
                            <p class="text-muted">Проведено в этом месяце</p>
                        </div>
                        <div class="col-md-3">
                            <h3 class="text-warning">
                                <?php echo e($user->markedLessons()->count()); ?>

                            </h3>
                            <p class="text-muted">Всего отмечено</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Groups -->
            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0">Группы преподавателя</h5>
                </div>
                <div class="card-body">
                    <?php if($user->groups->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Код</th>
                                        <th>Название</th>
                                        <th>Предмет</th>
                                        <th>Курс</th>
                                        <th>Студентов</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $user->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><strong><?php echo e($group->code); ?></strong></td>
                                            <td><?php echo e($group->name); ?></td>
                                            <td><?php echo e($group->pivot->subject); ?></td>
                                            <td><?php echo e($group->course); ?></td>
                                            <td><?php echo e($group->students->count()); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.groups.show', $group)); ?>" 
                                                   class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted mb-0">Нет назначенных групп</p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Recent Schedules -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Последние занятия</h5>
            </div>
            <div class="card-body">
                <?php if($user->schedules->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Дата</th>
                                    <th>Время</th>
                                    <th>Группа</th>
                                    <th>Предмет</th>
                                    <th>Статус</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($schedule->date->format('d.m.Y')); ?></td>
                                        <td><?php echo e($schedule->time_range); ?></td>
                                        <td><?php echo e($schedule->group->code); ?></td>
                                        <td><?php echo e($schedule->subject); ?></td>
                                        <td>
                                            <?php if($schedule->is_cancelled): ?>
                                                <span class="badge bg-secondary">Отменено</span>
                                            <?php elseif($schedule->lesson && $schedule->lesson->is_conducted): ?>
                                                <span class="badge bg-success">Проведено</span>
                                            <?php elseif($schedule->isPast()): ?>
                                                <span class="badge bg-warning">Не отмечено</span>
                                            <?php else: ?>
                                                <span class="badge bg-light text-dark">Запланировано</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.schedules.show', $schedule)); ?>" 
                                               class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted mb-0">Нет занятий</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Apache24\htdocs\lesson-tracking-system\resources\views/admin/users/show.blade.php ENDPATH**/ ?>