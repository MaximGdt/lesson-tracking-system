

<?php $__env->startSection('title', 'Просмотр группы'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($group->code); ?> - <?php echo e($group->name); ?></h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <a href="<?php echo e(route('admin.groups.edit', $group)); ?>" class="btn btn-primary">
                <i class="bi bi-pencil"></i> Редактировать
            </a>
            <form method="POST" action="<?php echo e(route('admin.groups.sync-students', $group)); ?>" class="d-inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-success">
                    <i class="bi bi-arrow-repeat"></i> Синхронизировать студентов
                </button>
            </form>
        </div>
        <a href="<?php echo e(route('admin.groups.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Назад
        </a>
    </div>
</div>

<div class="row">
    <!-- Group Info -->
    <div class="col-lg-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Информация о группе</h5>
            </div>
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-sm-5">Код:</dt>
                    <dd class="col-sm-7"><strong><?php echo e($group->code); ?></strong></dd>
                    
                    <dt class="col-sm-5">Название:</dt>
                    <dd class="col-sm-7"><?php echo e($group->name); ?></dd>
                    
                    <dt class="col-sm-5">Курс:</dt>
                    <dd class="col-sm-7"><?php echo e($group->course); ?></dd>
                    
                    <dt class="col-sm-5">Специальность:</dt>
                    <dd class="col-sm-7"><?php echo e($group->speciality ?? '-'); ?></dd>
                    
                    <dt class="col-sm-5">Начало обучения:</dt>
                    <dd class="col-sm-7"><?php echo e($group->start_date ? $group->start_date->format('d.m.Y') : '-'); ?></dd>
                    
                    <dt class="col-sm-5">Окончание:</dt>
                    <dd class="col-sm-7"><?php echo e($group->end_date ? $group->end_date->format('d.m.Y') : '-'); ?></dd>
                    
                    <dt class="col-sm-5">Статус:</dt>
                    <dd class="col-sm-7">
                        <?php if($group->is_active): ?>
                            <span class="badge bg-success">Активна</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Неактивна</span>
                        <?php endif; ?>
                    </dd>
                    
                    <dt class="col-sm-5">Студентов:</dt>
                    <dd class="col-sm-7"><span class="badge bg-info"><?php echo e($group->students->count()); ?></span></dd>
                </dl>
                
                <?php if($group->description): ?>
                    <hr>
                    <p class="mb-0 small"><?php echo e($group->description); ?></p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Teachers -->
        <div class="card mt-3">
            <div class="card-header">
                <h5 class="mb-0">Преподаватели</h5>
            </div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $group->teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div>
                            <strong><?php echo e($teacher->full_name); ?></strong><br>
                            <small class="text-muted"><?php echo e($teacher->pivot->subject); ?></small>
                        </div>
                        <a href="<?php echo e(route('admin.users.show', $teacher)); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-person"></i>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted mb-0">Преподаватели не назначены</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Students List -->
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Список студентов (<?php echo e($group->students->count()); ?>)</h5>
                <?php if($group->students->first() && $group->students->first()->synced_at): ?>
                    <small class="text-muted">
                        Синхронизировано: <?php echo e($group->students->first()->synced_at->format('d.m.Y H:i')); ?>

                    </small>
                <?php endif; ?>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>№</th>
                                <th>ФИО</th>
                                <th>Email</th>
                                <th>Телефон</th>
                                <th>№ студ. билета</th>
                                <th>Статус</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $group->students->sortBy('last_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($student->full_name); ?></td>
                                    <td><?php echo e($student->email ?? '-'); ?></td>
                                    <td><?php echo e($student->phone ?? '-'); ?></td>
                                    <td><?php echo e($student->student_card_number ?? '-'); ?></td>
                                    <td>
                                        <?php if($student->is_active): ?>
                                            <span class="badge bg-success">Активен</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Неактивен</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-muted">
                                        Список студентов пуст. Выполните синхронизацию.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Upcoming Schedules -->
        <div class="card mt-3">
            <div class="card-header">
                <h5 class="mb-0">Ближайшие занятия</h5>
            </div>
            <div class="card-body">
                <?php if($upcomingSchedules->isEmpty()): ?>
                    <p class="text-muted mb-0">Нет запланированных занятий</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Дата</th>
                                    <th>Время</th>
                                    <th>Предмет</th>
                                    <th>Преподаватель</th>
                                    <th>Аудитория</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $upcomingSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($schedule->date->format('d.m.Y')); ?></td>
                                        <td><?php echo e($schedule->time_range); ?></td>
                                        <td><?php echo e($schedule->subject); ?></td>
                                        <td><?php echo e($schedule->teacher->short_name); ?></td>
                                        <td><?php echo e($schedule->room ?? '-'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Apache24\htdocs\lesson-tracking-system\resources\views/admin/groups/show.blade.php ENDPATH**/ ?>